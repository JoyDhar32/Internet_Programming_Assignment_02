<?php
$conn = mysqli_connect('localhost','root','','rental_history');
?>